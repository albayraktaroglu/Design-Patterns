package com.AdapterPattern;

public class Engineer{

	private String firstname;
	private String lastname;
	private String cityname;

	public Engineer(String fn, String ln, String cn) {
		this.firstname = fn; 
		this.lastname = ln;
		this.cityname = cn;
	}

	public String gFirstname() {
		return this.firstname;
	}

	public String gLastname() {
		return this.lastname;
	}

	public String gCityname() {
		return this.cityname;
	}

	

}
