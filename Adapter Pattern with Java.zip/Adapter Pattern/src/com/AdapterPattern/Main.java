package com.AdapterPattern;

import java.util.ArrayList;
import java.util.List;

public class Main {

	public static void main(String[] args) {
		
		/**
		 * Adapter Pattern Implementation 
		 * 	Engineers trying to be represented as typical Employee 	
		 *	
		 *	Engineer Class - trying to be as normal employee for the system understood
		 *	Employee Interface - interface that how system know all employee ( such as engineer, teacher, etc...)
		 *	EmployeeAdapter Class - that helps to represent engineers as normal employee 
		 *	
		 */
		
		// List of all employees 
		List <Employee> listOfEmployee = new ArrayList<Employee>();
		
		// Adding employees from different departments 
		listOfEmployee.add(new EmployeeAdapter(new Engineer("Michael","SurN","New York")) );
		listOfEmployee.add(new TeacherAdapter(new Teacher("Tname","Tsurname","Washington")) );
		
		// Printing all employees
		for(Employee person:listOfEmployee){
			System.out.println("Name: "+person.getFirstName());
			System.out.println("Surname: "+person.getLastName());
			System.out.println("City: "+person.getCityName());
			System.out.println("______________________________");
		}
		
	}

}
