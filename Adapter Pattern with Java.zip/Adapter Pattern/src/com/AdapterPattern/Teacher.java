package com.AdapterPattern;

public class Teacher {
	private String firstname;
	private String lastname;
	private String cityname;

	public Teacher(String fn, String ln, String cn) {
		this.firstname = fn; 
		this.lastname = ln;
		this.cityname = cn;
	}

	public String teacherName() {
		return this.firstname;
	}

	public String teacherLastname() {
		return this.lastname;
	}

	public String teacherCityname() {
		return this.cityname;
	}
	
	public String toString(){
		return " Teacher -> " +this.firstname+" "+this.lastname+" "+this.cityname;
	}

}
