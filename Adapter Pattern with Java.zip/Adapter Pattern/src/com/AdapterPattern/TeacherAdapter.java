package com.AdapterPattern;

public class TeacherAdapter implements Employee{

	private Teacher teach;
	
	public TeacherAdapter(Teacher t){
		this.teach = t;
	}
	@Override
	public String getFirstName() {
		return this.teach.teacherName();
	}

	@Override
	public String getLastName() {
		return this.teach.teacherLastname();
	}

	@Override
	public String getCityName() {
		return this.teach.teacherCityname();
	}

}
