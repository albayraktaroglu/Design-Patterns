package com.AdapterPattern;

public class EmployeeAdapter implements Employee {
	
	private Engineer eng;
	
	public EmployeeAdapter(Engineer e){
		this.eng = e;
	}
	

	@Override
	public String getFirstName() {
		return this.eng.gFirstname();
	}

	@Override
	public String getLastName() {
		return this.eng.gLastname();
	}

	@Override
	public String getCityName() {
		return this.eng.gCityname();
	}

}
