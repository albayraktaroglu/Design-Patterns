package com.AdapterPattern;

public interface Employee {
	
	public String getFirstName();
	public String getLastName();
	public String getCityName();
	
}
